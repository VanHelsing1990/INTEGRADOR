# 🍔 Food Store – Sistema de Gestión de Pedidos

Trabajo Práctico Integrador — Programación 2 | UTN

---

## 📋 Descripción

Aplicación de consola en Java 21 para la gestión de un negocio de comidas.
Permite administrar categorías, productos, usuarios y pedidos con persistencia
en MySQL mediante JDBC puro, aplicando POO y el patrón DAO.

---

## 🛠 Requisitos

| Herramienta | Versión mínima |
|-------------|---------------|
| Java JDK    | 21            |
| Maven       | 3.8+          |
| MySQL       | 8.0+          |

---

## ⚙️ Configuración paso a paso

### 1. Crear la base de datos

Abrí MySQL Workbench o la terminal de MySQL y ejecutá:

```sql
SOURCE /ruta/al/proyecto/schema.sql;
```

O bien copiá y pegá el contenido de `schema.sql` directamente.

### 2. Configurar la conexión

Editá el archivo `src/main/resources/persistence.xml`:

```xml
<connection>
    <driver>com.mysql.cj.jdbc.Driver</driver>
    <url>jdbc:mysql://localhost:3306/pedidos_db?useSSL=false&amp;serverTimezone=UTC&amp;allowPublicKeyRetrieval=true</url>
    <username>TU_USUARIO</username>
    <password>TU_CONTRASEÑA</password>
</connection>
```

### 3. Compilar el proyecto

```bash
mvn clean package -DskipTests
```

### 4. Ejecutar

```bash
java -jar target/food-store.jar
```

O desde tu IDE (IntelliJ / Eclipse): ejecutá la clase `foodstore.Main`.

---

## 📁 Estructura del proyecto

```
src/main/java/foodstore/
├── Main.java                    # Punto de entrada
├── config/
│   └── ConexionDB.java          # Lee persistence.xml y provee Connection
├── entities/
│   ├── Base.java                # Clase abstracta base (id, eliminado, createdAt)
│   ├── Calculable.java          # Interfaz con calcularTotal()
│   ├── Categoria.java
│   ├── Producto.java
│   ├── Usuario.java
│   ├── Pedido.java              # Implementa Calculable
│   └── DetallePedido.java
├── enums/
│   ├── Rol.java                 # ADMIN, USUARIO
│   ├── Estado.java              # PENDIENTE, CONFIRMADO, TERMINADO, CANCELADO
│   └── FormaPago.java           # TARJETA, TRANSFERENCIA, EFECTIVO
├── dao/
│   ├── interfaces/
│   │   └── IBaseDAO.java        # Interfaz genérica CRUD
│   ├── CategoriaDAO.java
│   ├── ProductoDAO.java
│   ├── UsuarioDAO.java
│   ├── PedidoDAO.java           # Maneja transacción (Pedido + Detalles)
│   └── DetallePedidoDAO.java
├── service/
│   ├── CategoriaService.java
│   ├── ProductoService.java
│   ├── UsuarioService.java
│   └── PedidoService.java
├── ui/
│   ├── Consola.java             # Utilidades de entrada/salida
│   ├── CategoriaMenu.java
│   ├── ProductoMenu.java
│   ├── UsuarioMenu.java
│   └── PedidoMenu.java
└── exception/
    ├── EntityNotFoundException.java
    └── ValidationException.java
```

---

## 🧩 Decisiones técnicas

- **Soft delete**: ninguna entidad se borra físicamente. Se usa `eliminado = true`.
- **Transacciones**: al crear un pedido, se usa `connection.setAutoCommit(false)` con `rollback` ante fallas.
- **Interfaz genérica**: `IBaseDAO<T>` unifica los métodos CRUD de todos los DAOs.
- **Calculable**: `Pedido` implementa la interfaz y calcula el total sumando subtotales de los detalles.
- **Validaciones**: realizadas en la capa Service antes de llegar al DAO.

---

## 🎥 Video demostrativo

> _[Insertar link al video aquí]_

## 📄 Documentación PDF

> _[Insertar link al PDF aquí]_
