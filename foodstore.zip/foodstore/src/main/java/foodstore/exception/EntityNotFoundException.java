package foodstore.exception;

public class EntityNotFoundException extends RuntimeException {
    public EntityNotFoundException(String entity, Long id) {
        super("No se encontró " + entity + " con ID: " + id);
    }
}
