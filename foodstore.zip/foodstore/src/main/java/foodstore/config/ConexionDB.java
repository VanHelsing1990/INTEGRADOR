package foodstore.config;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {

    private static final String url;
    private static final String username;
    private static final String password;

    static {
        try {
            InputStream is = ConexionDB.class
                    .getClassLoader()
                    .getResourceAsStream("persistence.xml");
            if (is == null) throw new RuntimeException("No se encontró persistence.xml en resources/");

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(is);
            doc.getDocumentElement().normalize();

            Element conn = (Element) doc.getElementsByTagName("connection").item(0);
            String driver = conn.getElementsByTagName("driver").item(0).getTextContent().trim();
            url      = conn.getElementsByTagName("url").item(0).getTextContent().trim();
            username = conn.getElementsByTagName("username").item(0).getTextContent().trim();
            password = conn.getElementsByTagName("password").item(0).getTextContent().trim();

            Class.forName(driver);

        } catch (Exception e) {
            throw new RuntimeException("Error al cargar configuración de BD: " + e.getMessage(), e);
        }
    }

    private ConexionDB() {}

    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }
}
