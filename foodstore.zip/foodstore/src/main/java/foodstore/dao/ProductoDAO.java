package foodstore.dao;

import foodstore.config.ConexionDB;
import foodstore.dao.interfaces.IBaseDAO;
import foodstore.entities.Categoria;
import foodstore.entities.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductoDAO implements IBaseDAO<Producto> {

    @Override
    public void guardar(Producto p) throws SQLException {
        String sql = "INSERT INTO producto (nombre, descripcion, precio, stock, imagen, disponible, categoria_id, eliminado, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, false, NOW())";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getStock());
            ps.setString(5, p.getImagen());
            ps.setBoolean(6, p.isDisponible());
            ps.setLong(7, p.getCategoria().getId());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) p.setId(rs.getLong(1));
            }
        }
    }

    @Override
    public void actualizar(Producto p) throws SQLException {
        String sql = "UPDATE producto SET nombre=?, descripcion=?, precio=?, stock=?, imagen=?, disponible=?, categoria_id=? " +
                     "WHERE id=? AND eliminado=false";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getStock());
            ps.setString(5, p.getImagen());
            ps.setBoolean(6, p.isDisponible());
            ps.setLong(7, p.getCategoria().getId());
            ps.setLong(8, p.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(Long id) throws SQLException {
        String sql = "UPDATE producto SET eliminado=true WHERE id=?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Optional<Producto> buscarPorId(Long id) throws SQLException {
        String sql = "SELECT p.*, c.nombre AS cat_nombre, c.descripcion AS cat_desc " +
                     "FROM producto p JOIN categoria c ON p.categoria_id = c.id " +
                     "WHERE p.id=? AND p.eliminado=false";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Producto> listarTodos() throws SQLException {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT p.*, c.nombre AS cat_nombre, c.descripcion AS cat_desc " +
                     "FROM producto p JOIN categoria c ON p.categoria_id = c.id " +
                     "WHERE p.eliminado=false ORDER BY p.nombre";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public List<Producto> listarPorCategoria(Long categoriaId) throws SQLException {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT p.*, c.nombre AS cat_nombre, c.descripcion AS cat_desc " +
                     "FROM producto p JOIN categoria c ON p.categoria_id = c.id " +
                     "WHERE p.categoria_id=? AND p.eliminado=false ORDER BY p.nombre";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, categoriaId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private Producto mapear(ResultSet rs) throws SQLException {
        Categoria cat = new Categoria(
                rs.getLong("categoria_id"),
                rs.getString("cat_nombre"),
                rs.getString("cat_desc")
        );
        Producto p = new Producto(
                rs.getLong("id"),
                rs.getString("nombre"),
                rs.getDouble("precio"),
                rs.getString("descripcion"),
                rs.getInt("stock"),
                rs.getString("imagen"),
                rs.getBoolean("disponible"),
                cat
        );
        p.setEliminado(rs.getBoolean("eliminado"));
        p.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return p;
    }
}
