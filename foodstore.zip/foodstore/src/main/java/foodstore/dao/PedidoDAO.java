package foodstore.dao;

import foodstore.config.ConexionDB;
import foodstore.dao.interfaces.IBaseDAO;
import foodstore.entities.*;
import foodstore.enums.Estado;
import foodstore.enums.FormaPago;
import foodstore.enums.Rol;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PedidoDAO implements IBaseDAO<Pedido> {

    private final DetallePedidoDAO detalleDAO = new DetallePedidoDAO();

    @Override
    public void guardar(Pedido p) throws SQLException {
        String sql = "INSERT INTO pedido (fecha, estado, total, forma_pago, usuario_id, eliminado, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, false, NOW())";
        Connection con = null;
        try {
            con = ConexionDB.getConexion();
            con.setAutoCommit(false);

            try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setDate(1, Date.valueOf(p.getFecha()));
                ps.setString(2, p.getEstado().name());
                ps.setDouble(3, p.getTotal());
                ps.setString(4, p.getFormaPago().name());
                ps.setLong(5, p.getUsuario().getId());
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) p.setId(rs.getLong(1));
                }
            }

            for (DetallePedido d : p.getDetalles()) {
                detalleDAO.guardarConConexion(d, p.getId(), con);
            }

            con.commit();

        } catch (SQLException e) {
            if (con != null) {
                try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            throw e;
        } finally {
            if (con != null) {
                try { con.setAutoCommit(true); con.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }
    }

    @Override
    public void actualizar(Pedido p) throws SQLException {
        String sql = "UPDATE pedido SET estado=?, forma_pago=?, total=? WHERE id=? AND eliminado=false";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getEstado().name());
            ps.setString(2, p.getFormaPago().name());
            ps.setDouble(3, p.getTotal());
            ps.setLong(4, p.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(Long id) throws SQLException {
        Connection con = null;
        try {
            con = ConexionDB.getConexion();
            con.setAutoCommit(false);

            String sqlDetalle = "UPDATE detalle_pedido SET eliminado=true WHERE pedido_id=?";
            try (PreparedStatement ps = con.prepareStatement(sqlDetalle)) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }

            String sqlPedido = "UPDATE pedido SET eliminado=true WHERE id=?";
            try (PreparedStatement ps = con.prepareStatement(sqlPedido)) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }

            con.commit();
        } catch (SQLException e) {
            if (con != null) try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            throw e;
        } finally {
            if (con != null) try { con.setAutoCommit(true); con.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }

    @Override
    public Optional<Pedido> buscarPorId(Long id) throws SQLException {
        String sql = "SELECT p.*, u.nombre AS u_nombre, u.apellido AS u_apellido, u.mail AS u_mail, " +
                     "u.celular AS u_celular, u.contrasena AS u_contrasena, u.rol AS u_rol " +
                     "FROM pedido p JOIN usuario u ON p.usuario_id = u.id " +
                     "WHERE p.id=? AND p.eliminado=false";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Pedido pedido = mapear(rs);
                    pedido.setDetalles(detalleDAO.listarPorPedido(id));
                    return Optional.of(pedido);
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Pedido> listarTodos() throws SQLException {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT p.*, u.nombre AS u_nombre, u.apellido AS u_apellido, u.mail AS u_mail, " +
                     "u.celular AS u_celular, u.contrasena AS u_contrasena, u.rol AS u_rol " +
                     "FROM pedido p JOIN usuario u ON p.usuario_id = u.id " +
                     "WHERE p.eliminado=false ORDER BY p.fecha DESC";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public List<Pedido> listarPorUsuario(Long usuarioId) throws SQLException {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT p.*, u.nombre AS u_nombre, u.apellido AS u_apellido, u.mail AS u_mail, " +
                     "u.celular AS u_celular, u.contrasena AS u_contrasena, u.rol AS u_rol " +
                     "FROM pedido p JOIN usuario u ON p.usuario_id = u.id " +
                     "WHERE p.usuario_id=? AND p.eliminado=false ORDER BY p.fecha DESC";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private Pedido mapear(ResultSet rs) throws SQLException {
        Usuario u = new Usuario(
                rs.getLong("usuario_id"),
                rs.getString("u_nombre"),
                rs.getString("u_apellido"),
                rs.getString("u_mail"),
                rs.getString("u_celular"),
                rs.getString("u_contrasena"),
                Rol.valueOf(rs.getString("u_rol"))
        );
        Pedido p = new Pedido(
                rs.getLong("id"),
                rs.getDate("fecha").toLocalDate(),
                Estado.valueOf(rs.getString("estado")),
                rs.getDouble("total"),
                FormaPago.valueOf(rs.getString("forma_pago")),
                u
        );
        p.setEliminado(rs.getBoolean("eliminado"));
        p.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return p;
    }
}
