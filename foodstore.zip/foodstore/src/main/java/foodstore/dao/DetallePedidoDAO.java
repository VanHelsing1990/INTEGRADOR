package foodstore.dao;

import foodstore.config.ConexionDB;
import foodstore.dao.interfaces.IBaseDAO;
import foodstore.entities.Categoria;
import foodstore.entities.DetallePedido;
import foodstore.entities.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DetallePedidoDAO implements IBaseDAO<DetallePedido> {

    @Override
    public void guardar(DetallePedido d) throws SQLException {
        throw new UnsupportedOperationException("Usar guardarConConexion() para transacciones.");
    }

    /** Inserta el detalle usando una conexión ya abierta (para manejar transacción en PedidoDAO). */
    public void guardarConConexion(DetallePedido d, Long pedidoId, Connection con) throws SQLException {
        String sql = "INSERT INTO detalle_pedido (cantidad, subtotal, producto_id, pedido_id, eliminado, created_at) " +
                     "VALUES (?, ?, ?, ?, false, NOW())";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, d.getCantidad());
            ps.setDouble(2, d.getSubtotal());
            ps.setLong(3, d.getProducto().getId());
            ps.setLong(4, pedidoId);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) d.setId(rs.getLong(1));
            }
        }
    }

    @Override
    public void actualizar(DetallePedido d) throws SQLException {
        String sql = "UPDATE detalle_pedido SET cantidad=?, subtotal=? WHERE id=? AND eliminado=false";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, d.getCantidad());
            ps.setDouble(2, d.getSubtotal());
            ps.setLong(3, d.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(Long id) throws SQLException {
        String sql = "UPDATE detalle_pedido SET eliminado=true WHERE id=?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Optional<DetallePedido> buscarPorId(Long id) throws SQLException {
        String sql = "SELECT dp.*, p.nombre AS prod_nombre, p.precio, p.descripcion, p.stock, " +
                     "p.imagen, p.disponible, p.categoria_id, c.nombre AS cat_nombre, c.descripcion AS cat_desc " +
                     "FROM detalle_pedido dp " +
                     "JOIN producto p ON dp.producto_id = p.id " +
                     "JOIN categoria c ON p.categoria_id = c.id " +
                     "WHERE dp.id=? AND dp.eliminado=false";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }
        }
        return Optional.empty();
    }

    @Override
    public List<DetallePedido> listarTodos() throws SQLException {
        throw new UnsupportedOperationException("Usar listarPorPedido(Long pedidoId).");
    }

    public List<DetallePedido> listarPorPedido(Long pedidoId) throws SQLException {
        List<DetallePedido> lista = new ArrayList<>();
        String sql = "SELECT dp.*, p.nombre AS prod_nombre, p.precio, p.descripcion, p.stock, " +
                     "p.imagen, p.disponible, p.categoria_id, c.nombre AS cat_nombre, c.descripcion AS cat_desc " +
                     "FROM detalle_pedido dp " +
                     "JOIN producto p ON dp.producto_id = p.id " +
                     "JOIN categoria c ON p.categoria_id = c.id " +
                     "WHERE dp.pedido_id=? AND dp.eliminado=false";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, pedidoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        }
        return lista;
    }

    private DetallePedido mapear(ResultSet rs) throws SQLException {
        Categoria cat = new Categoria(
                rs.getLong("categoria_id"),
                rs.getString("cat_nombre"),
                rs.getString("cat_desc")
        );
        Producto prod = new Producto(
                rs.getLong("producto_id"),
                rs.getString("prod_nombre"),
                rs.getDouble("precio"),
                rs.getString("descripcion"),
                rs.getInt("stock"),
                rs.getString("imagen"),
                rs.getBoolean("disponible"),
                cat
        );
        DetallePedido d = new DetallePedido(
                rs.getLong("id"),
                rs.getInt("cantidad"),
                rs.getDouble("subtotal"),
                prod
        );
        d.setEliminado(rs.getBoolean("eliminado"));
        d.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return d;
    }
}
