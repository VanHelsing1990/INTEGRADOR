package foodstore.service;

import foodstore.dao.UsuarioDAO;
import foodstore.entities.Usuario;
import foodstore.enums.Rol;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;

import java.sql.SQLException;
import java.util.List;

public class UsuarioService {

    private final UsuarioDAO dao = new UsuarioDAO();

    public List<Usuario> listar() throws SQLException {
        return dao.listarTodos();
    }

    public Usuario buscarPorId(Long id) throws SQLException {
        return dao.buscarPorId(id)
                .orElseThrow(() -> new EntityNotFoundException("Usuario", id));
    }

    public void crear(String nombre, String apellido, String mail,
                      String celular, String contrasena, Rol rol) throws SQLException {
        validarCampos(nombre, apellido, mail);
        if (dao.existeMailEnOtroUsuario(mail, null))
            throw new ValidationException("Ya existe un usuario con el mail: " + mail);
        Usuario u = new Usuario(nombre.trim(), apellido.trim(), mail.trim(),
                                celular.trim(), contrasena.trim(), rol);
        dao.guardar(u);
        System.out.println("✔ Usuario creado con ID: " + u.getId());
    }

    public void editar(Long id, String nombre, String apellido, String mail,
                       String celular, String contrasena, Rol rol) throws SQLException {
        Usuario u = buscarPorId(id);
        validarCampos(nombre, apellido, mail);
        if (dao.existeMailEnOtroUsuario(mail, id))
            throw new ValidationException("Ya existe otro usuario con el mail: " + mail);
        u.setNombre(nombre.trim());
        u.setApellido(apellido.trim());
        u.setMail(mail.trim());
        u.setCelular(celular.trim());
        u.setContrasena(contrasena.trim());
        u.setRol(rol);
        dao.actualizar(u);
        System.out.println("✔ Usuario actualizado correctamente.");
    }

    public void eliminar(Long id) throws SQLException {
        buscarPorId(id);
        dao.eliminar(id);
        System.out.println("✔ Usuario eliminado (baja lógica).");
    }

    private void validarCampos(String nombre, String apellido, String mail) {
        if (nombre == null || nombre.isBlank())
            throw new ValidationException("El nombre no puede estar vacío.");
        if (apellido == null || apellido.isBlank())
            throw new ValidationException("El apellido no puede estar vacío.");
        if (mail == null || !mail.contains("@"))
            throw new ValidationException("El mail ingresado no es válido.");
    }
}
