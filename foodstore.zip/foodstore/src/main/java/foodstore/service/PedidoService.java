package foodstore.service;

import foodstore.dao.PedidoDAO;
import foodstore.entities.Pedido;
import foodstore.entities.Producto;
import foodstore.entities.Usuario;
import foodstore.enums.Estado;
import foodstore.enums.FormaPago;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;

import java.sql.SQLException;
import java.util.List;

public class PedidoService {

    private final PedidoDAO dao = new PedidoDAO();
    private final UsuarioService usuarioService = new UsuarioService();
    private final ProductoService productoService = new ProductoService();

    public List<Pedido> listar() throws SQLException {
        return dao.listarTodos();
    }

    public List<Pedido> listarPorUsuario(Long usuarioId) throws SQLException {
        return dao.listarPorUsuario(usuarioId);
    }

    public Pedido buscarPorId(Long id) throws SQLException {
        return dao.buscarPorId(id)
                .orElseThrow(() -> new EntityNotFoundException("Pedido", id));
    }

    /**
     * Crea un pedido completo con sus detalles.
     * Usa la interfaz Calculable (calcularTotal) y addDetallePedido del UML.
     */
    public Pedido iniciarPedido(Long usuarioId, FormaPago formaPago) throws SQLException {
        Usuario u = usuarioService.buscarPorId(usuarioId);
        return new Pedido(u, formaPago);
    }

    public void agregarDetalle(Pedido pedido, Long productoId, int cantidad) throws SQLException {
        if (cantidad <= 0)
            throw new ValidationException("La cantidad debe ser mayor a 0.");
        Producto p = productoService.buscarPorId(productoId);
        // Usa el método del UML
        pedido.addDetallePedido(cantidad, p.getPrecio(), p);
        System.out.printf("  ✔ Agregado: %s x%d ($%.2f)%n",
                p.getNombre(), cantidad, p.getPrecio() * cantidad);
    }

    public void confirmarPedido(Pedido pedido) throws SQLException {
        if (pedido.getDetalles().isEmpty())
            throw new ValidationException("El pedido debe tener al menos un detalle.");
        // Usa la interfaz Calculable
        pedido.calcularTotal();
        dao.guardar(pedido);
        System.out.printf("✔ Pedido #%d guardado. Total: $%.2f%n",
                pedido.getId(), pedido.getTotal());
    }

    public void actualizarEstadoYPago(Long id, Estado estado, FormaPago formaPago) throws SQLException {
        Pedido p = buscarPorId(id);
        p.setEstado(estado);
        p.setFormaPago(formaPago);
        dao.actualizar(p);
        System.out.println("✔ Pedido actualizado correctamente.");
    }

    public void eliminar(Long id) throws SQLException {
        buscarPorId(id);
        dao.eliminar(id);
        System.out.println("✔ Pedido eliminado (baja lógica).");
    }
}
