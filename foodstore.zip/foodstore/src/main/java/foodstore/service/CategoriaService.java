package foodstore.service;

import foodstore.dao.CategoriaDAO;
import foodstore.entities.Categoria;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;

import java.sql.SQLException;
import java.util.List;

public class CategoriaService {

    private final CategoriaDAO dao = new CategoriaDAO();

    public List<Categoria> listar() throws SQLException {
        return dao.listarTodos();
    }

    public Categoria buscarPorId(Long id) throws SQLException {
        return dao.buscarPorId(id)
                .orElseThrow(() -> new EntityNotFoundException("Categoría", id));
    }

    public void crear(String nombre, String descripcion) throws SQLException {
        validarNombre(nombre);
        validarDescripcion(descripcion);
        Categoria c = new Categoria(nombre.trim(), descripcion.trim());
        dao.guardar(c);
        System.out.println("✔ Categoría creada con ID: " + c.getId());
    }

    public void editar(Long id, String nombre, String descripcion) throws SQLException {
        Categoria c = buscarPorId(id);
        validarNombre(nombre);
        validarDescripcion(descripcion);
        c.setNombre(nombre.trim());
        c.setDescripcion(descripcion.trim());
        dao.actualizar(c);
        System.out.println("✔ Categoría actualizada correctamente.");
    }

    public void eliminar(Long id) throws SQLException {
        buscarPorId(id); // verifica que exista
        if (dao.tieneProductos(id)) {
            throw new ValidationException(
                "La categoría tiene productos activos asociados. Eliminá primero los productos.");
        }
        dao.eliminar(id);
        System.out.println("✔ Categoría eliminada (baja lógica).");
    }

    private void validarNombre(String nombre) {
        if (nombre == null || nombre.isBlank())
            throw new ValidationException("El nombre no puede estar vacío.");
    }

    private void validarDescripcion(String descripcion) {
        if (descripcion == null || descripcion.isBlank())
            throw new ValidationException("La descripción no puede estar vacía.");
    }
}
