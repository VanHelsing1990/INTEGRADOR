package foodstore.service;

import foodstore.dao.ProductoDAO;
import foodstore.entities.Categoria;
import foodstore.entities.Producto;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;

import java.sql.SQLException;
import java.util.List;

public class ProductoService {

    private final ProductoDAO dao = new ProductoDAO();
    private final CategoriaService categoriaService = new CategoriaService();

    public List<Producto> listar() throws SQLException {
        return dao.listarTodos();
    }

    public List<Producto> listarPorCategoria(Long categoriaId) throws SQLException {
        return dao.listarPorCategoria(categoriaId);
    }

    public Producto buscarPorId(Long id) throws SQLException {
        return dao.buscarPorId(id)
                .orElseThrow(() -> new EntityNotFoundException("Producto", id));
    }

    public void crear(String nombre, String descripcion, Double precio, int stock,
                      String imagen, boolean disponible, Long categoriaId) throws SQLException {
        validar(nombre, precio, stock);
        Categoria cat = categoriaService.buscarPorId(categoriaId);
        Producto p = new Producto(nombre.trim(), precio, descripcion.trim(),
                                  stock, imagen.trim(), disponible, cat);
        dao.guardar(p);
        System.out.println("✔ Producto creado con ID: " + p.getId());
    }

    public void editar(Long id, String nombre, String descripcion, Double precio,
                       int stock, String imagen, boolean disponible, Long categoriaId) throws SQLException {
        Producto p = buscarPorId(id);
        validar(nombre, precio, stock);
        Categoria cat = categoriaService.buscarPorId(categoriaId);
        p.setNombre(nombre.trim());
        p.setDescripcion(descripcion.trim());
        p.setPrecio(precio);
        p.setStock(stock);
        p.setImagen(imagen.trim());
        p.setDisponible(disponible);
        p.setCategoria(cat);
        dao.actualizar(p);
        System.out.println("✔ Producto actualizado correctamente.");
    }

    public void eliminar(Long id) throws SQLException {
        buscarPorId(id);
        dao.eliminar(id);
        System.out.println("✔ Producto eliminado (baja lógica).");
    }

    private void validar(String nombre, Double precio, int stock) {
        if (nombre == null || nombre.isBlank())
            throw new ValidationException("El nombre no puede estar vacío.");
        if (precio == null || precio < 0)
            throw new ValidationException("El precio no puede ser negativo.");
        if (stock < 0)
            throw new ValidationException("El stock no puede ser negativo.");
    }
}
