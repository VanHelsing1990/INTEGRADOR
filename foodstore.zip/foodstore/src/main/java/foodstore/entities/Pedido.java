package foodstore.entities;

import foodstore.enums.Estado;
import foodstore.enums.FormaPago;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Pedido extends Base implements Calculable {

    private LocalDate fecha;
    private Estado estado;
    private Double total;
    private FormaPago formaPago;
    private Usuario usuario;
    private List<DetallePedido> detalles;

    public Pedido() {
        super();
        this.detalles = new ArrayList<>();
        this.fecha = LocalDate.now();
        this.estado = Estado.PENDIENTE;
        this.total = 0.0;
    }

    public Pedido(Usuario usuario, FormaPago formaPago) {
        this();
        this.usuario = usuario;
        this.formaPago = formaPago;
    }

    public Pedido(Long id, LocalDate fecha, Estado estado, Double total,
                  FormaPago formaPago, Usuario usuario) {
        super(id);
        this.fecha = fecha;
        this.estado = estado;
        this.total = total;
        this.formaPago = formaPago;
        this.usuario = usuario;
        this.detalles = new ArrayList<>();
    }

    // ── Métodos propios del UML ──────────────────────────────────────────────

    public void addDetallePedido(int cantidad, Double precioUnitario, Producto producto) {
        double subtotal = cantidad * precioUnitario;
        DetallePedido detalle = new DetallePedido(cantidad, subtotal, producto);
        detalles.add(detalle);
    }

    public DetallePedido findeDetallePedidoByProducto(Producto producto) {
        Optional<DetallePedido> result = detalles.stream()
                .filter(d -> d.getProducto().equals(producto))
                .findFirst();
        return result.orElse(null);
    }

    public void deleteDetallePedidoByProducto(Producto producto) {
        detalles.removeIf(d -> d.getProducto().equals(producto));
    }

    // ── Calculable ───────────────────────────────────────────────────────────

    @Override
    public void calcularTotal() {
        this.total = detalles.stream()
                .mapToDouble(DetallePedido::getSubtotal)
                .sum();
    }

    // ── Getters / Setters ────────────────────────────────────────────────────

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public Estado getEstado() { return estado; }
    public void setEstado(Estado estado) { this.estado = estado; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public FormaPago getFormaPago() { return formaPago; }
    public void setFormaPago(FormaPago formaPago) { this.formaPago = formaPago; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public List<DetallePedido> getDetalles() { return detalles; }
    public void setDetalles(List<DetallePedido> detalles) { this.detalles = detalles; }

    @Override
    public String toString() {
        String user = (usuario != null)
                ? usuario.getNombre() + " " + usuario.getApellido()
                : "Sin usuario";
        return String.format("| %-4d | %-22s | %-12s | %-14s | $%-10.2f | %s |",
                id, user, estado, formaPago, total, fecha);
    }
}
