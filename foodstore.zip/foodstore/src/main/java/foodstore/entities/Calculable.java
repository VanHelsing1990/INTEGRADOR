package foodstore.entities;

public interface Calculable {
    void calcularTotal();
}
