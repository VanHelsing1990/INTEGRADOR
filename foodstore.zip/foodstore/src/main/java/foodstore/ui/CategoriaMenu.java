package foodstore.ui;

import foodstore.entities.Categoria;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;
import foodstore.service.CategoriaService;

import java.sql.SQLException;
import java.util.List;

public class CategoriaMenu {

    private final CategoriaService service = new CategoriaService();

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            Consola.titulo("GESTIÓN DE CATEGORÍAS");
            System.out.println("  1. Listar categorías");
            System.out.println("  2. Crear categoría");
            System.out.println("  3. Editar categoría");
            System.out.println("  4. Eliminar categoría");
            System.out.println("  0. Volver al menú principal");
            Consola.separador();

            int op = Consola.leerInt("  Seleccione: ");
            switch (op) {
                case 1 -> listar();
                case 2 -> crear();
                case 3 -> editar();
                case 4 -> eliminar();
                case 0 -> volver = true;
                default -> System.out.println("  ⚠ Opción inválida.");
            }
        }
    }

    private void listar() {
        Consola.titulo("LISTADO DE CATEGORÍAS");
        try {
            List<Categoria> lista = service.listar();
            if (lista.isEmpty()) {
                System.out.println("  No hay categorías cargadas.");
            } else {
                System.out.printf("  | %-4s | %-25s | %-40s |%n", "ID", "Nombre", "Descripción");
                Consola.separador();
                lista.forEach(c -> System.out.println("  " + c));
            }
        } catch (SQLException e) {
            System.out.println("  ✖ Error al listar: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void crear() {
        Consola.titulo("CREAR CATEGORÍA");
        try {
            String nombre = Consola.leerTexto("  Nombre: ");
            String descripcion = Consola.leerTexto("  Descripción: ");
            service.crear(nombre, descripcion);
        } catch (ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate"))
                System.out.println("  ✖ Ya existe una categoría con ese nombre.");
            else
                System.out.println("  ✖ Error al crear: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void editar() {
        Consola.titulo("EDITAR CATEGORÍA");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID a editar: ");
            Categoria actual = service.buscarPorId(id);
            System.out.println("  Actual → " + actual);
            System.out.println("  (Dejá en blanco para mantener el valor actual)");

            String nombre = Consola.leerTexto("  Nuevo nombre [" + actual.getNombre() + "]: ");
            if (nombre.isBlank()) nombre = actual.getNombre();

            String desc = Consola.leerTexto("  Nueva descripción [" + actual.getDescripcion() + "]: ");
            if (desc.isBlank()) desc = actual.getDescripcion();

            service.editar(id, nombre, desc);
        } catch (EntityNotFoundException | ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error al editar: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void eliminar() {
        Consola.titulo("ELIMINAR CATEGORÍA");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID a eliminar: ");
            if (Consola.confirmar("  ¿Confirmar eliminación?")) {
                service.eliminar(id);
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (EntityNotFoundException | ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error al eliminar: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void listarSilencioso() {
        try {
            List<Categoria> lista = service.listar();
            if (!lista.isEmpty()) {
                System.out.printf("  | %-4s | %-25s |%n", "ID", "Nombre");
                lista.forEach(c -> System.out.printf("  | %-4d | %-25s |%n", c.getId(), c.getNombre()));
                System.out.println();
            }
        } catch (SQLException ignored) {}
    }
}
