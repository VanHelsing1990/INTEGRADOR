package foodstore.ui;

import foodstore.entities.Usuario;
import foodstore.enums.Rol;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;
import foodstore.service.UsuarioService;

import java.sql.SQLException;
import java.util.List;

public class UsuarioMenu {

    private final UsuarioService service = new UsuarioService();

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            Consola.titulo("GESTIÓN DE USUARIOS");
            System.out.println("  1. Listar usuarios");
            System.out.println("  2. Crear usuario");
            System.out.println("  3. Editar usuario");
            System.out.println("  4. Eliminar usuario");
            System.out.println("  0. Volver al menú principal");
            Consola.separador();

            int op = Consola.leerInt("  Seleccione: ");
            switch (op) {
                case 1 -> listar();
                case 2 -> crear();
                case 3 -> editar();
                case 4 -> eliminar();
                case 0 -> volver = true;
                default -> System.out.println("  ⚠ Opción inválida.");
            }
        }
    }

    private void listar() {
        Consola.titulo("LISTADO DE USUARIOS");
        try {
            List<Usuario> lista = service.listar();
            if (lista.isEmpty()) {
                System.out.println("  No hay usuarios registrados.");
            } else {
                System.out.printf("  | %-4s | %-15s | %-15s | %-30s | %-13s | %-8s |%n",
                        "ID", "Nombre", "Apellido", "Mail", "Celular", "Rol");
                Consola.separador();
                lista.forEach(u -> System.out.println("  " + u));
            }
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void crear() {
        Consola.titulo("CREAR USUARIO");
        try {
            String nombre    = Consola.leerTexto("  Nombre: ");
            String apellido  = Consola.leerTexto("  Apellido: ");
            String mail      = Consola.leerTexto("  Mail: ");
            String celular   = Consola.leerTexto("  Celular: ");
            String contrasena = Consola.leerTexto("  Contraseña: ");
            Rol rol = elegirRol();
            service.crear(nombre, apellido, mail, celular, contrasena, rol);
        } catch (ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("Duplicate"))
                System.out.println("  ✖ Ya existe un usuario con ese mail.");
            else
                System.out.println("  ✖ Error al crear: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void editar() {
        Consola.titulo("EDITAR USUARIO");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID a editar: ");
            Usuario actual = service.buscarPorId(id);
            System.out.println("  Actual → " + actual);

            String nombre = Consola.leerTexto("  Nuevo nombre [" + actual.getNombre() + "]: ");
            if (nombre.isBlank()) nombre = actual.getNombre();

            String apellido = Consola.leerTexto("  Nuevo apellido [" + actual.getApellido() + "]: ");
            if (apellido.isBlank()) apellido = actual.getApellido();

            String mail = Consola.leerTexto("  Nuevo mail [" + actual.getMail() + "]: ");
            if (mail.isBlank()) mail = actual.getMail();

            String celular = Consola.leerTexto("  Nuevo celular [" + actual.getCelular() + "]: ");
            if (celular.isBlank()) celular = actual.getCelular();

            String contrasena = Consola.leerTexto("  Nueva contraseña (en blanco para no cambiar): ");
            if (contrasena.isBlank()) contrasena = actual.getContrasena();

            System.out.println("  Rol actual: " + actual.getRol());
            Rol rol = Consola.leerBoolean("  ¿Cambiar rol?") ? elegirRol() : actual.getRol();

            service.editar(id, nombre, apellido, mail, celular, contrasena, rol);
        } catch (EntityNotFoundException | ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error al editar: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void eliminar() {
        Consola.titulo("ELIMINAR USUARIO");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID a eliminar: ");
            if (Consola.confirmar("  ¿Confirmar eliminación?")) {
                service.eliminar(id);
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (EntityNotFoundException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error al eliminar: " + e.getMessage());
        }
        Consola.pausar();
    }

    private Rol elegirRol() {
        System.out.println("  Roles disponibles:");
        Rol[] roles = Rol.values();
        for (int i = 0; i < roles.length; i++)
            System.out.printf("    %d. %s%n", i + 1, roles[i]);
        while (true) {
            int op = Consola.leerInt("  Seleccione rol: ");
            if (op >= 1 && op <= roles.length) return roles[op - 1];
            System.out.println("  ⚠ Opción inválida.");
        }
    }

    private void listarSilencioso() {
        try {
            List<Usuario> lista = service.listar();
            if (!lista.isEmpty()) {
                System.out.printf("  | %-4s | %-15s | %-15s | %-30s |%n", "ID", "Nombre", "Apellido", "Mail");
                lista.forEach(u -> System.out.printf("  | %-4d | %-15s | %-15s | %-30s |%n",
                        u.getId(), u.getNombre(), u.getApellido(), u.getMail()));
                System.out.println();
            }
        } catch (SQLException ignored) {}
    }
}
