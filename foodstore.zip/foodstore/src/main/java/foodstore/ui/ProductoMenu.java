package foodstore.ui;

import foodstore.entities.Categoria;
import foodstore.entities.Producto;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;
import foodstore.service.CategoriaService;
import foodstore.service.ProductoService;

import java.sql.SQLException;
import java.util.List;

public class ProductoMenu {

    private final ProductoService service = new ProductoService();
    private final CategoriaService categoriaService = new CategoriaService();

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            Consola.titulo("GESTIÓN DE PRODUCTOS");
            System.out.println("  1. Listar todos los productos");
            System.out.println("  2. Listar productos por categoría");
            System.out.println("  3. Crear producto");
            System.out.println("  4. Editar producto");
            System.out.println("  5. Eliminar producto");
            System.out.println("  0. Volver al menú principal");
            Consola.separador();

            int op = Consola.leerInt("  Seleccione: ");
            switch (op) {
                case 1 -> listar();
                case 2 -> listarPorCategoria();
                case 3 -> crear();
                case 4 -> editar();
                case 5 -> eliminar();
                case 0 -> volver = true;
                default -> System.out.println("  ⚠ Opción inválida.");
            }
        }
    }

    private void listar() {
        Consola.titulo("LISTADO DE PRODUCTOS");
        try {
            List<Producto> lista = service.listar();
            if (lista.isEmpty()) {
                System.out.println("  No hay productos cargados.");
            } else {
                System.out.printf("  | %-4s | %-22s | %-10s | %-6s | %-15s | %-13s |%n",
                        "ID", "Nombre", "Precio", "Stock", "Categoría", "Estado");
                Consola.separador();
                lista.forEach(p -> System.out.println("  " + p));
            }
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void listarPorCategoria() {
        Consola.titulo("PRODUCTOS POR CATEGORÍA");
        mostrarCategorias();
        try {
            long catId = Consola.leerLong("  ID de categoría: ");
            List<Producto> lista = service.listarPorCategoria(catId);
            if (lista.isEmpty()) {
                System.out.println("  No hay productos en esa categoría.");
            } else {
                lista.forEach(p -> System.out.println("  " + p));
            }
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void crear() {
        Consola.titulo("CREAR PRODUCTO");
        mostrarCategorias();
        try {
            String nombre = Consola.leerTexto("  Nombre: ");
            String descripcion = Consola.leerTexto("  Descripción: ");
            double precio = Consola.leerDouble("  Precio: $");
            int stock = Consola.leerInt("  Stock: ");
            String imagen = Consola.leerTexto("  Imagen (URL o nombre): ");
            boolean disponible = Consola.leerBoolean("  ¿Disponible?");
            long catId = Consola.leerLong("  ID de categoría: ");

            service.crear(nombre, descripcion, precio, stock, imagen, disponible, catId);
        } catch (EntityNotFoundException | ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error al crear: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void editar() {
        Consola.titulo("EDITAR PRODUCTO");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID a editar: ");
            Producto actual = service.buscarPorId(id);
            System.out.println("  Actual → " + actual);
            System.out.println("  (Dejá en blanco / 0 para mantener valor actual)");

            String nombre = Consola.leerTexto("  Nuevo nombre [" + actual.getNombre() + "]: ");
            if (nombre.isBlank()) nombre = actual.getNombre();

            String desc = Consola.leerTexto("  Nueva descripción [" + actual.getDescripcion() + "]: ");
            if (desc.isBlank()) desc = actual.getDescripcion();

            String precioStr = Consola.leerTexto("  Nuevo precio [" + actual.getPrecio() + "]: ");
            double precio = precioStr.isBlank() ? actual.getPrecio() : Double.parseDouble(precioStr.replace(',', '.'));

            String stockStr = Consola.leerTexto("  Nuevo stock [" + actual.getStock() + "]: ");
            int stock = stockStr.isBlank() ? actual.getStock() : Integer.parseInt(stockStr);

            String imagen = Consola.leerTexto("  Nueva imagen [" + actual.getImagen() + "]: ");
            if (imagen.isBlank()) imagen = actual.getImagen();

            boolean disponible = Consola.leerBoolean("  ¿Disponible? (actual: " + actual.isDisponible() + ")");

            mostrarCategorias();
            String catStr = Consola.leerTexto("  ID de categoría [" + actual.getCategoria().getId() + "]: ");
            long catId = catStr.isBlank() ? actual.getCategoria().getId() : Long.parseLong(catStr);

            service.editar(id, nombre, desc, precio, stock, imagen, disponible, catId);
        } catch (EntityNotFoundException | ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("  ⚠ Valor numérico inválido.");
        } catch (SQLException e) {
            System.out.println("  ✖ Error al editar: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void eliminar() {
        Consola.titulo("ELIMINAR PRODUCTO");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID a eliminar: ");
            if (Consola.confirmar("  ¿Confirmar eliminación?")) {
                service.eliminar(id);
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (EntityNotFoundException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error al eliminar: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void listarSilencioso() {
        try {
            List<Producto> lista = service.listar();
            if (!lista.isEmpty()) {
                System.out.printf("  | %-4s | %-22s | %-10s |%n", "ID", "Nombre", "Precio");
                lista.forEach(p -> System.out.printf("  | %-4d | %-22s | $%-9.2f |%n",
                        p.getId(), p.getNombre(), p.getPrecio()));
                System.out.println();
            }
        } catch (SQLException ignored) {}
    }

    private void mostrarCategorias() {
        try {
            List<Categoria> cats = categoriaService.listar();
            System.out.println("  Categorías disponibles:");
            cats.forEach(c -> System.out.printf("    [%d] %s%n", c.getId(), c.getNombre()));
        } catch (SQLException ignored) {}
    }
}
