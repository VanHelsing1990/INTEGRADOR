package foodstore.ui;

import java.util.Scanner;

public class Consola {

    private static final Scanner sc = new Scanner(System.in);

    private Consola() {}

    public static int leerInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String linea = sc.nextLine().trim();
            try {
                return Integer.parseInt(linea);
            } catch (NumberFormatException e) {
                System.out.println("  ⚠ Ingresá un número entero válido.");
            }
        }
    }

    public static long leerLong(String prompt) {
        while (true) {
            System.out.print(prompt);
            String linea = sc.nextLine().trim();
            try {
                return Long.parseLong(linea);
            } catch (NumberFormatException e) {
                System.out.println("  ⚠ Ingresá un número válido.");
            }
        }
    }

    public static double leerDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String linea = sc.nextLine().trim();
            try {
                double v = Double.parseDouble(linea.replace(',', '.'));
                if (v < 0) { System.out.println("  ⚠ El valor no puede ser negativo."); continue; }
                return v;
            } catch (NumberFormatException e) {
                System.out.println("  ⚠ Ingresá un número válido (ej: 150.50).");
            }
        }
    }

    public static String leerTexto(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    public static boolean leerBoolean(String prompt) {
        while (true) {
            System.out.print(prompt + " (s/n): ");
            String r = sc.nextLine().trim().toLowerCase();
            if (r.equals("s") || r.equals("si") || r.equals("sí")) return true;
            if (r.equals("n") || r.equals("no")) return false;
            System.out.println("  ⚠ Ingresá 's' o 'n'.");
        }
    }

    public static boolean confirmar(String prompt) {
        return leerBoolean(prompt);
    }

    public static void pausar() {
        System.out.print("\n  Presioná ENTER para continuar...");
        sc.nextLine();
    }

    public static void separador() {
        System.out.println("─".repeat(80));
    }

    public static void titulo(String texto) {
        System.out.println();
        separador();
        System.out.println("  " + texto);
        separador();
    }
}
