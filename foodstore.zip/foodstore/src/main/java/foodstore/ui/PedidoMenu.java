package foodstore.ui;

import foodstore.entities.DetallePedido;
import foodstore.entities.Pedido;
import foodstore.entities.Producto;
import foodstore.entities.Usuario;
import foodstore.enums.Estado;
import foodstore.enums.FormaPago;
import foodstore.exception.EntityNotFoundException;
import foodstore.exception.ValidationException;
import foodstore.service.PedidoService;
import foodstore.service.ProductoService;
import foodstore.service.UsuarioService;

import java.sql.SQLException;
import java.util.List;

public class PedidoMenu {

    private final PedidoService service      = new PedidoService();
    private final UsuarioService usuarioService = new UsuarioService();
    private final ProductoService productoService = new ProductoService();

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            Consola.titulo("GESTIÓN DE PEDIDOS");
            System.out.println("  1. Listar pedidos");
            System.out.println("  2. Listar pedidos por usuario");
            System.out.println("  3. Ver detalle de un pedido");
            System.out.println("  4. Crear pedido");
            System.out.println("  5. Actualizar estado / forma de pago");
            System.out.println("  6. Eliminar pedido");
            System.out.println("  0. Volver al menú principal");
            Consola.separador();

            int op = Consola.leerInt("  Seleccione: ");
            switch (op) {
                case 1 -> listar();
                case 2 -> listarPorUsuario();
                case 3 -> verDetalle();
                case 4 -> crear();
                case 5 -> actualizarEstado();
                case 6 -> eliminar();
                case 0 -> volver = true;
                default -> System.out.println("  ⚠ Opción inválida.");
            }
        }
    }

    private void listar() {
        Consola.titulo("LISTADO DE PEDIDOS");
        try {
            List<Pedido> lista = service.listar();
            if (lista.isEmpty()) {
                System.out.println("  No hay pedidos registrados.");
            } else {
                System.out.printf("  | %-4s | %-22s | %-12s | %-14s | %-12s | %-10s |%n",
                        "ID", "Usuario", "Estado", "Forma de Pago", "Total", "Fecha");
                Consola.separador();
                lista.forEach(p -> System.out.println("  " + p));
            }
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void listarPorUsuario() {
        Consola.titulo("PEDIDOS POR USUARIO");
        mostrarUsuarios();
        try {
            long uid = Consola.leerLong("  ID de usuario: ");
            List<Pedido> lista = service.listarPorUsuario(uid);
            if (lista.isEmpty()) {
                System.out.println("  El usuario no tiene pedidos.");
            } else {
                lista.forEach(p -> System.out.println("  " + p));
            }
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void verDetalle() {
        Consola.titulo("DETALLE DE PEDIDO");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID del pedido: ");
            Pedido p = service.buscarPorId(id);
            System.out.println("  " + p);
            System.out.println("\n  Detalles:");
            List<DetallePedido> detalles = p.getDetalles();
            if (detalles.isEmpty()) {
                System.out.println("    Sin detalles.");
            } else {
                detalles.forEach(d -> System.out.println("  " + d));
                System.out.printf("%n  TOTAL: $%.2f%n", p.getTotal());
            }
        } catch (EntityNotFoundException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void crear() {
        Consola.titulo("CREAR PEDIDO");
        try {
            // 1. Seleccionar usuario
            mostrarUsuarios();
            long uid = Consola.leerLong("  ID de usuario: ");

            // 2. Seleccionar forma de pago
            FormaPago fp = elegirFormaPago();

            // 3. Iniciar pedido (valida usuario en service)
            Pedido pedido = service.iniciarPedido(uid, fp);

            // 4. Agregar detalles
            boolean agregarMas = true;
            while (agregarMas) {
                mostrarProductos();
                long prodId = Consola.leerLong("  ID de producto: ");
                int cantidad = Consola.leerInt("  Cantidad: ");
                try {
                    service.agregarDetalle(pedido, prodId, cantidad);
                } catch (EntityNotFoundException | ValidationException e) {
                    System.out.println("  ⚠ " + e.getMessage());
                }
                agregarMas = Consola.leerBoolean("  ¿Agregar otro producto?");
            }

            // 5. Confirmar y persistir (usa calcularTotal y transacción)
            if (Consola.confirmar("  ¿Confirmar pedido?")) {
                service.confirmarPedido(pedido);
            } else {
                System.out.println("  Pedido cancelado.");
            }

        } catch (EntityNotFoundException | ValidationException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error al crear pedido: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void actualizarEstado() {
        Consola.titulo("ACTUALIZAR PEDIDO");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID del pedido: ");
            Estado estado = elegirEstado();
            FormaPago fp  = elegirFormaPago();
            service.actualizarEstadoYPago(id, estado, fp);
        } catch (EntityNotFoundException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    private void eliminar() {
        Consola.titulo("ELIMINAR PEDIDO");
        listarSilencioso();
        try {
            long id = Consola.leerLong("  ID a eliminar: ");
            if (Consola.confirmar("  ¿Confirmar eliminación?")) {
                service.eliminar(id);
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (EntityNotFoundException e) {
            System.out.println("  ⚠ " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("  ✖ Error: " + e.getMessage());
        }
        Consola.pausar();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private Estado elegirEstado() {
        Estado[] estados = Estado.values();
        System.out.println("  Estados:");
        for (int i = 0; i < estados.length; i++)
            System.out.printf("    %d. %s%n", i + 1, estados[i]);
        while (true) {
            int op = Consola.leerInt("  Seleccione estado: ");
            if (op >= 1 && op <= estados.length) return estados[op - 1];
            System.out.println("  ⚠ Opción inválida.");
        }
    }

    private FormaPago elegirFormaPago() {
        FormaPago[] formas = FormaPago.values();
        System.out.println("  Formas de pago:");
        for (int i = 0; i < formas.length; i++)
            System.out.printf("    %d. %s%n", i + 1, formas[i]);
        while (true) {
            int op = Consola.leerInt("  Seleccione forma de pago: ");
            if (op >= 1 && op <= formas.length) return formas[op - 1];
            System.out.println("  ⚠ Opción inválida.");
        }
    }

    private void mostrarUsuarios() {
        try {
            List<Usuario> usuarios = usuarioService.listar();
            System.out.println("  Usuarios disponibles:");
            usuarios.forEach(u -> System.out.printf("    [%d] %s %s (%s)%n",
                    u.getId(), u.getNombre(), u.getApellido(), u.getMail()));
        } catch (SQLException ignored) {}
    }

    private void mostrarProductos() {
        try {
            List<Producto> productos = productoService.listar();
            System.out.println("  Productos disponibles:");
            productos.forEach(p -> System.out.printf("    [%d] %-22s $%.2f (Stock: %d)%n",
                    p.getId(), p.getNombre(), p.getPrecio(), p.getStock()));
        } catch (SQLException ignored) {}
    }

    private void listarSilencioso() {
        try {
            List<Pedido> lista = service.listar();
            if (!lista.isEmpty()) {
                System.out.printf("  | %-4s | %-22s | %-12s | %-10s |%n",
                        "ID", "Usuario", "Estado", "Total");
                lista.forEach(p -> System.out.printf("  | %-4d | %-22s | %-12s | $%-9.2f |%n",
                        p.getId(),
                        p.getUsuario().getNombre() + " " + p.getUsuario().getApellido(),
                        p.getEstado(),
                        p.getTotal()));
                System.out.println();
            }
        } catch (SQLException ignored) {}
    }
}
