package foodstore;

import foodstore.ui.*;

public class Main {

    public static void main(String[] args) {
        CategoriaMenu categoriaMenu = new CategoriaMenu();
        ProductoMenu  productoMenu  = new ProductoMenu();
        UsuarioMenu   usuarioMenu   = new UsuarioMenu();
        PedidoMenu    pedidoMenu    = new PedidoMenu();

        boolean corriendo = true;
        while (corriendo) {
            Consola.titulo("SISTEMA DE PEDIDOS — FOOD STORE");
            System.out.println("  1. Categorías");
            System.out.println("  2. Productos");
            System.out.println("  3. Usuarios");
            System.out.println("  4. Pedidos");
            System.out.println("  0. Salir");
            Consola.separador();

            int op = Consola.leerInt("  Seleccione: ");
            switch (op) {
                case 1 -> categoriaMenu.mostrar();
                case 2 -> productoMenu.mostrar();
                case 3 -> usuarioMenu.mostrar();
                case 4 -> pedidoMenu.mostrar();
                case 0 -> {
                    System.out.println("\n  ¡Hasta luego! 🍔");
                    corriendo = false;
                }
                default -> System.out.println("  ⚠ Opción inválida.");
            }
        }
    }
}
