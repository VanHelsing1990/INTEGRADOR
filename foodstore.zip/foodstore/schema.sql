-- ============================================================
-- Food Store – Schema SQL
-- Base de datos: pedidos_db
-- ============================================================

CREATE DATABASE IF NOT EXISTS pedidos_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE pedidos_db;

-- ── Tabla: categoria ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categoria (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(255) NOT NULL,
    eliminado   BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Tabla: producto ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS producto (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre       VARCHAR(150) NOT NULL,
    descripcion  VARCHAR(255) NOT NULL,
    precio       DOUBLE       NOT NULL CHECK (precio >= 0),
    stock        INT          NOT NULL CHECK (stock >= 0),
    imagen       VARCHAR(255),
    disponible   BOOLEAN      NOT NULL DEFAULT TRUE,
    categoria_id BIGINT       NOT NULL,
    eliminado    BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_prod_cat FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);

-- ── Tabla: usuario ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usuario (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre     VARCHAR(100) NOT NULL,
    apellido   VARCHAR(100) NOT NULL,
    mail       VARCHAR(150) NOT NULL UNIQUE,
    celular    VARCHAR(30),
    contrasena VARCHAR(255) NOT NULL,
    rol        ENUM('ADMIN','USUARIO') NOT NULL DEFAULT 'USUARIO',
    eliminado  BOOLEAN  NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Tabla: pedido ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pedido (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha      DATE    NOT NULL,
    estado     ENUM('PENDIENTE','CONFIRMADO','TERMINADO','CANCELADO') NOT NULL DEFAULT 'PENDIENTE',
    total      DOUBLE  NOT NULL DEFAULT 0,
    forma_pago ENUM('TARJETA','TRANSFERENCIA','EFECTIVO') NOT NULL,
    usuario_id BIGINT  NOT NULL,
    eliminado  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ped_usr FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

-- ── Tabla: detalle_pedido ────────────────────────────────────
CREATE TABLE IF NOT EXISTS detalle_pedido (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    cantidad   INT    NOT NULL CHECK (cantidad > 0),
    subtotal   DOUBLE NOT NULL,
    producto_id BIGINT NOT NULL,
    pedido_id  BIGINT NOT NULL,
    eliminado  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_det_prod FOREIGN KEY (producto_id) REFERENCES producto(id),
    CONSTRAINT fk_det_ped  FOREIGN KEY (pedido_id)  REFERENCES pedido(id)
);

-- ============================================================
-- Datos de ejemplo
-- ============================================================

-- Categorías
INSERT INTO categoria (nombre, descripcion) VALUES
('Hamburguesas', 'Hamburguesas artesanales con ingredientes frescos'),
('Pizzas',       'Pizzas a la piedra con masa de fermentación lenta'),
('Bebidas',      'Gaseosas, aguas y jugos naturales'),
('Postres',      'Dulces y helados para cerrar la comida');

-- Productos
INSERT INTO producto (nombre, descripcion, precio, stock, imagen, disponible, categoria_id) VALUES
('Hamburguesa Clásica',  'Carne vacuna, lechuga, tomate y cheddar',   1200.00, 50, 'hamburguesaclasica.jpg',  true, 1),
('Hamburguesa BBQ',      'Carne con salsa BBQ y cebolla caramelizada', 1450.00, 30, 'hamburguesabbq.jpg',      true, 1),
('Pizza Mozzarella',     'Mozzarella, tomate y albahaca fresca',       1800.00, 20, 'pizzamozzarella.jpg',     true, 2),
('Pizza Napolitana',     'Mozzarella, tomate y fetas de ajo',          1900.00, 20, 'pizzanapolitana.jpg',     true, 2),
('Coca-Cola 500ml',      'Gaseosa Coca-Cola botella 500ml',             400.00, 100,'cocacola500.jpg',         true, 3),
('Agua sin gas 500ml',   'Agua mineral sin gas',                        250.00, 100,'aguasingaz.jpg',          true, 3),
('Brownie con helado',   'Brownie de chocolate con helado de vainilla', 800.00, 25, 'brownie.jpg',             true, 4);

-- Usuarios
INSERT INTO usuario (nombre, apellido, mail, celular, contrasena, rol) VALUES
('Admin',  'Sistema', 'admin@foodstore.com',  '3410000000', 'admin123',  'ADMIN'),
('Juan',   'Perez',   'juan@mail.com',         '3411111111', 'juan123',   'USUARIO'),
('Maria',  'Gomez',   'maria@mail.com',        '3412222222', 'maria123',  'USUARIO');

-- Pedido de ejemplo
INSERT INTO pedido (fecha, estado, total, forma_pago, usuario_id) VALUES
('2026-03-01', 'CONFIRMADO', 3250.00, 'EFECTIVO', 2);

INSERT INTO detalle_pedido (cantidad, subtotal, producto_id, pedido_id) VALUES
(2, 2400.00, 1, 1),
(1,  400.00, 5, 1),
(1,  450.00, 7, 1);
